let date=getElementByclass('date');
if (departure-date>arrial-date)
{
   alert("Please Enter the again")
}